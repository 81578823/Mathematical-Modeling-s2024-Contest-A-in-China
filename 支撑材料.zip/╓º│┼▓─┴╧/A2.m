clc
clear

gap = 0.55;     %螺距
k = gap/(2*pi);
v_h = 1;        %龙头速度
theta_s = 32*pi;
len_h = 2.86;   %龙头长
len_b = 1.65;   %龙身长
w = 0.15;       %板凳半宽
len_e = 0.275;  %把手前长度

inner = zeros(1002,1);  %条带内层厚度
outer = zeros(1002,1);  %条带外层厚度
tmp = zeros(1002,1);

func_len = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5));
tot_s = func_len(theta_s);  %总长

for theta_a = 0:0.1:100 %前把手极角
    pos = zeros(2,2);
    func_tb = @(dtheta) k^2*(theta_a+dtheta)^2 - 2*k^2*theta_a*(theta_a+dtheta)*cos(dtheta) + k^2*theta_a^2 - len_b^2;
    dtheta = fsolve(func_tb, 0.15);
    theta_b = theta_a + dtheta; %后把手极角
    pos(1,1) = k*theta_a*cos(theta_a);  %前把手x
    pos(1,2) = k*theta_a*sin(theta_a);  %前把手y
    pos(2,1) = k*theta_b*cos(theta_b);  %后把手x
    pos(2,2) = k*theta_b*sin(theta_b);  %前把手y
    kq = (pos(1,2)-pos(2,2))/(pos(1,1)-pos(2,1));   %把手间连线斜率
    d = abs(kq*pos(1,1)-pos(1,2)) / sqrt(kq^2+1);
    kq = -1/kq;
    theta_i = atan(kq);
    if theta_i<0
        theta_i = theta_i + pi;
    end
    theta_i = theta_i + pi*floor(theta_a/pi);   %内层条带最厚处对应极角
    r = k*theta_i;
    inner(round(theta_i*10)+1) = max(inner(round(theta_i*10)+1),r-d+w);
end
inner(inner==0) = NaN;
inner = fillmissing(inner, "linear");   %线性插值补全缺失值

for theta_a = 0:0.1:100
    pos = zeros(4,2);
    func_th = @(dtheta) k^2*(theta_a+dtheta)^2 - 2*k^2*theta_a*(theta_a+dtheta)*cos(dtheta) + k^2*theta_a^2 - len_h^2;
    dtheta = fsolve(func_th, 0.15);
    theta_b = theta_a + dtheta;
    pos(1,1) = k*theta_a*cos(theta_a);
    pos(1,2) = k*theta_a*sin(theta_a);
    pos(2,1) = k*theta_b*cos(theta_b);
    pos(2,2) = k*theta_b*sin(theta_b);
    pos(3,1) = pos(1,1) + (pos(1,1)-pos(2,1))*len_e/len_h;
    pos(3,2) = pos(1,2) + (pos(1,2)-pos(2,2))*len_e/len_h;
    pos(4,1) = pos(3,1) + (pos(1,2)-pos(3,2))*w/len_e;  %角点x
    pos(4,2) = pos(3,2) - (pos(1,1)-pos(3,1))*w/len_e;  %角点y
    d = (pos(4,1)^2+pos(4,2)^2)^0.5;
    theta_o = atan2(pos(4,2),pos(4,1));
    if theta_o<0
        theta_o = theta_o + 2*pi;
    end
    theta_o = theta_o + 2*pi*floor(theta_a/pi/2);   %外层条带最厚处对应极角
    if (pos(1,1)>0) && (pos(1,2)>0) && (pos(4,1)>0) && (pos(4,2)<0)
        theta_o = theta_o - 2*pi;
    end
    r = k*theta_o;
    if theta_o < 0
        theta_o = 0;
    end
    outer(round(theta_o*10)+1) = max(outer(round(theta_o*10)+1),d-r);
end
outer(outer==0) = NaN;
outer = fillmissing(outer, "linear");

for theta = 75:-0.1:2*pi    %从后向前搜索碰撞点
    tmp(round(theta*10)+1) = inner(round(theta*10)+1) + outer(round((theta-2*pi)*10)+1);
    if (inner(round(theta*10)+1) + outer(round((theta-2*pi)*10)+1)) >= gap
        theta = theta - 2*pi;
        ans = (tot_s - func_len(theta))/v_h;
        disp(theta)
        disp(ans)
        break
    end
end
coli_x = (k*theta+outer(round(theta*10)+1))*cos(theta); %碰撞点
coli_y = (k*theta+outer(round(theta*10)+1))*sin(theta);

%画图部分
theta1 = linspace(0, theta_s, 10000);
r_plt = k * theta1;
x_plt = r_plt .* cos(theta1);
y_plt = r_plt .* sin(theta1);

r_i = zeros(1, 1000);
r_o = zeros(1, 1000);
theta2 = linspace(0, 100, 1000);
for i = 1:1000
    r_i(i) = k * (i - 1) / 10 - inner(i);
    r_o(i) = k * (i - 1) / 10 + outer(i);
end

r_i = r_i(theta2 >= theta);
r_o = r_o(theta2 >= theta);
theta2 = theta2(theta2 >= theta);

x_i = r_i .* cos(theta2);
y_i = r_i .* sin(theta2);
x_o = r_o .* cos(theta2);
y_o = r_o .* sin(theta2);

figure;
l1 = plot(x_plt, y_plt, 'b', 'LineWidth', 1.5);
hold on;
plot(x_i, y_i, 'r', 'LineWidth', 0.5);
plot(x_o, y_o, 'r', 'LineWidth', 0.5);

fill_x = [x_i, fliplr(x_o)];
fill_y = [y_i, fliplr(y_o)];
l2 = fill(fill_x, fill_y, 'r', 'EdgeColor', 'none', 'FaceAlpha', 0.3);
l3 = plot(coli_x, coli_y, 'x', 'Color', 'y', 'MarkerSize', 20, 'LineWidth', 2);

hold off;
axis equal;
xlabel('X');
ylabel('Y');
legend([l1, l2, l3], {'螺线', '条带区域', '碰撞点'});
title('条带与碰撞点');
grid on;
