clc
clear

v_h = 1;        %龙头速度
theta_s = 32*pi;

len_h = 2.86;   %龙头长
len_b = 1.65;   %龙身长
w = 0.15;       %板凳半宽
len_e = 0.275;  %把手前长度

inner = zeros(702,1);
outer = zeros(702,1);

for gap = 0.55:-0.001:0 %螺距
   k = gap/(2*pi);
   theta_t = 4.5/k;
   for theta_a = 0:0.1:60   %前把手极角
        pos = zeros(2,2);
        func_tb = @(dtheta) k^2*(theta_a+dtheta)^2 - 2*k^2*theta_a*(theta_a+dtheta)*cos(dtheta) + k^2*theta_a^2 - len_b^2;
        dtheta = fsolve(func_tb, 0.15);
        theta_b = theta_a + dtheta; %后把手极角
        pos(1,1) = k*theta_a*cos(theta_a);  %前把手x
        pos(1,2) = k*theta_a*sin(theta_a);  %前把手y
        pos(2,1) = k*theta_b*cos(theta_b);  %后把手x
        pos(2,2) = k*theta_b*sin(theta_b);  %后把手y
        kq = (pos(1,2)-pos(2,2))/(pos(1,1)-pos(2,1));   %把手间连线斜率
        d = abs(kq*pos(1,1)-pos(1,2)) / sqrt(kq^2+1);
        kq = -1/kq;
        theta_i = atan(kq);
        if theta_i<0
            theta_i = theta_i + pi;
        end
        theta_i = theta_i + pi*floor(theta_a/pi);   %内层条带最厚处对应极角
        r = k*theta_i;
        inner(round(theta_i*10)+1) = max(inner(round(theta_i*10)+1),r-d+w);
    end
    inner(inner==0) = NaN;
    inner = fillmissing(inner, "linear");   %线性插值补全缺失值
    
    for theta_a = 0:0.1:60
        pos = zeros(4,2);
        func_th = @(dtheta) k^2*(theta_a+dtheta)^2 - 2*k^2*theta_a*(theta_a+dtheta)*cos(dtheta) + k^2*theta_a^2 - len_h^2;
        dtheta = fsolve(func_th, 0.15);
        theta_b = theta_a + dtheta;
        pos(1,1) = k*theta_a*cos(theta_a);
        pos(1,2) = k*theta_a*sin(theta_a);
        pos(2,1) = k*theta_b*cos(theta_b);
        pos(2,2) = k*theta_b*sin(theta_b);
        pos(3,1) = pos(1,1) + (pos(1,1)-pos(2,1))*len_e/len_h;
        pos(3,2) = pos(1,2) + (pos(1,2)-pos(2,2))*len_e/len_h;
        pos(4,1) = pos(3,1) + (pos(1,2)-pos(3,2))*w/len_e;  %角点x
        pos(4,2) = pos(3,2) - (pos(1,1)-pos(3,1))*w/len_e;  %角点y
        d = (pos(4,1)^2+pos(4,2)^2)^0.5;
        theta_o = atan2(pos(4,2),pos(4,1));
        if theta_o<0
            theta_o = theta_o + 2*pi;
        end
        theta_o = theta_o + 2*pi*floor(theta_a/pi/2);   %外层条带最厚处对应极角
        if (pos(1,1)>0) && (pos(1,2)>0) && (pos(4,1)>0) && (pos(4,2)<0)
            theta_o = theta_o - 2*pi;
        end
        r = k*theta_o;
        if theta_o < 0
            theta_o = 0;
        end
        outer(round(theta_o*10)+1) = max(outer(round(theta_o*10)+1),d-r);
    end
    outer(outer==0) = NaN;
    outer = fillmissing(outer, "linear");
    
    theta = 4.5/k;  %进入调头区域点极角
    if (inner(round(theta*10)+1) + outer(round((theta-2*pi)*10)+1)) >= gap
        break
    end
end
disp(gap)
