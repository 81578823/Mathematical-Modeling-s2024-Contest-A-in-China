clc
clear

% 开始计时
tic;


result_sen=zeros(1,2);
t_sen=zeros(1,1);

% 初始化参数
k = 0.65 / (2*pi);
v = 1; % m/s
dt = 0.0000001; % 时间步长
n_segments = 223;
lengths = [286, repmat(165, 1, 222)]; % cm
bench_width = 30; % cm
hole_distance = 27.5; % cm

% 定义螺线和弧长函数
spiral = @(theta) k * theta .* [cos(theta), sin(theta)];
S = @(theta) k * (theta/2 * sqrt(theta^2 + 1) + 1/2 * log(theta + sqrt(theta^2 + 1)));
S_tot= k * (32*pi/2 * sqrt((32*pi)^2 + 1) + 1/2 * log(32*pi+ sqrt((32*pi)^2 + 1)));


% 主循环
t = 517.026285;
positions = zeros(n_segments+1, 2);
velocities = zeros(n_segments+1, 1);
angles = zeros(n_segments+1, 1);
collision_detected = false;

while ~collision_detected
    t = t + dt;
    
    % 计算龙头位置
    theta_head = solve_theta(t, k, v,S,S_tot);
    positions(1,:) = spiral(theta_head);
    velocities(1) = v ;
    angles(1) = theta_head;
    
    % 计算龙身和龙尾
    for i = 2:n_segments+1
        d = lengths(i-1) / 100; % 转换为米
        func_tb = @(dtheta) k^2*(angles(i-1)+dtheta)^2 - 2*k^2*angles(i-1)*(angles(i-1)+dtheta)*cos(dtheta) + k^2*angles(i-1)^2 - d^2;
        dtheta = fsolve(func_tb, 0.15);
        angles(i) = angles(i-1) + dtheta;
        positions(i,:) = spiral(angles(i));
        velocities(i) = ((angles(i)^2+1)^0.5/(angles(i-1)^2+1)^0.5 * (angles(i)*angles(i-1)*sin(angles(i)-angles(i-1))+angles(i)*cos(angles(i)-angles(i-1))-angles(i-1)) ...
            / (angles(i)*angles(i-1)*sin(angles(i)-angles(i-1))-angles(i-1)*cos(angles(i)-angles(i-1))+angles(i)))*velocities(i-1);
    end
    
    % 碰撞检测
    [collision_detected, min_distance] = detect_collision(positions, angles);
    
end
result_sen(1,:)=positions(1,:);
t_sen=t;
% 输出结果
fprintf('终止时刻: %.6f 秒\n', t);
fprintf('最小距离: %.6f cm\n', min_distance * 100);

% 绘图
figure;
plot(positions(:,1), positions(:,2), 'b-o','LineWidth', 0.8);
hold on;
plot(positions(1,1), positions(1,2), 'ro', 'MarkerSize', 10,'LineWidth', 0.8, 'MarkerFaceColor', 'r');
plot(positions(end,1), positions(end,2), 'go', 'MarkerSize', 10,'LineWidth', 0.8, 'MarkerFaceColor', 'g');
title('螺距为0.65m下的板凳龙盘入终止时刻的位置');
xlabel('X (m)');
ylabel('Y (m)');
legend('龙身', '龙头', '龙尾');
axis equal;
grid on;


% 求解theta的函数
function theta = solve_theta(t, k, v, S,S_tot)
    f = @(th) S_tot - S(th) - v*t;
    theta = fsolve(f, 0);
end

% 碰撞检测函数
function [collision, min_distance] = detect_collision(positions, angles)
    n = size(positions, 1);
    collision = false;
    min_distance = inf;

    theta_h=atan2(positions(1,2)-positions(2,2),positions(1,1)-positions(2,1));
    
    % 龙头节点的长度和宽度
    head_length = 0.275; % 米
    head_width = 0.30; % 米
    
    % 龙身节点的长度和宽度
    body_length = 0.275; % 米
    body_width = 0.30; % 米
    
    % 龙头前端两个角点的位置
    head_front_left = positions(1,:) + [cos(theta_h)*head_length - sin(theta_h)*head_width/2, ...
                                        sin(theta_h)*head_length + cos(theta_h)*head_width/2];
    head_front_right = positions(1,:) + [cos(theta_h)*head_length + sin(theta_h)*head_width/2, ...
                                         sin(theta_h)*head_length - cos(theta_h)*head_width/2];
    
    % 检查龙头与每个龙身节点的碰撞
    for i = 2:n-1
        % 龙身节点的四个角点
        theta=atan2(positions(i,2)-positions(i+1,2),positions(i,1)-positions(i+1,1));

        body_corners = [              
            positions(i+1,:) + [-cos(theta)*body_length + sin(theta)*body_width/2, -sin(theta)*body_length - cos(theta)*body_width/2];         
            positions(i,:) + [cos(theta)*body_length + sin(theta)*body_width/2, sin(theta)*body_length - cos(theta)*body_width/2];
            positions(i,:) + [cos(theta)*body_length - sin(theta)*body_width/2, sin(theta)*body_length + cos(theta)*body_width/2];
            positions(i+1,:) + [-cos(theta)*body_length - sin(theta)*body_width/2, -sin(theta)*body_length + cos(theta)*body_width/2]

        ];
        
        % 检查龙头前端两个角点是否在龙身矩形内
        if is_point_in_rectangle(head_front_left, body_corners) || ...
           is_point_in_rectangle(head_front_right, body_corners)
            collision = true;
            d = min(min(pdist2(head_front_left, body_corners)), min(pdist2(head_front_right, body_corners)));
            min_distance = min(min_distance, d);
        end
    end
end

function in_rect = is_point_in_rectangle(point, corners)
    % 使用叉积判断点是否在矩形内
    in_rect = true;
    for i = 1:4
        v1 = corners(mod(i,4)+1,:) - corners(i,:);
        v2 = point - corners(i,:);
        if cross2d(v1, v2) < 0
            in_rect = false;
            break;
        end
    end
end

function z = cross2d(a, b)
    z = a(1)*b(2) - a(2)*b(1);
end