clc
clear
format long

% 初始化参数
k = 0.55/(2*pi);      % 螺线参数
v_h = 1;              % 龙头速度 (m/s)
theta_s = 32*pi;      % 初始角度
len_h = 2.86;         % 龙头长度 (m)
len_b = 1.65;         % 龙身长度 (m)

% 初始化结果数组
ans1 = zeros(448,301);  % 位置结果（x和y坐标）
ans2 = zeros(224,301);  % 速度结果

% 主循环：计算0到300秒的位置和速度
for t = 0:300
    theta = zeros(223,1);  % 初始化角度数组
    pos = zeros(224,2);    % 初始化位置数组
    v = zeros(224,1);      % 初始化速度数组
    
    % 计算总弧长
    tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
    
    % 计算龙头角度
    func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*t;
    theta_h = fsolve(func_sh, 0);
    
    % 计算第一个龙身节点的角度
    func_th = @(dtheta) k^2*(theta_h+dtheta)^2 - 2*k^2*theta_h*(theta_h+dtheta)*cos(dtheta) + k^2*theta_h^2 - len_h^2;
    dtheta = fsolve(func_th, 0.15);
    theta(1) = theta_h + dtheta;
    
    % 计算其余龙身节点的角度
    for i = 2:223
        func_tb = @(dtheta) k^2*(theta(i-1)+dtheta)^2 - 2*k^2*theta(i-1)*(theta(i-1)+dtheta)*cos(dtheta) + k^2*theta(i-1)^2 - len_b^2;
        dtheta = fsolve(func_tb, 0.15);
        theta(i) = theta(i-1) + dtheta;
    end
    
    % 计算速度
    v(1) = v_h;  % 龙头速度
    % 计算第一个龙身节点的速度
    v(2) = (theta(1)^2+1)^0.5/(theta_h^2+1)^0.5 * (theta(1)*theta_h*sin(theta(1)-theta_h)+theta(1)*cos(theta(1)-theta_h)-theta_h) ...
        / (theta(1)*theta_h*sin(theta(1)-theta_h)-theta_h*cos(theta(1)-theta_h)+theta(1));
    % 计算其余节点的速度
    for i = 2:223
        v(i+1) = ((theta(i)^2+1)^0.5/(theta(i-1)^2+1)^0.5 * (theta(i)*theta(i-1)*sin(theta(i)-theta(i-1))+theta(i)*cos(theta(i)-theta(i-1))-theta(i-1)) ...
            / (theta(i)*theta(i-1)*sin(theta(i)-theta(i-1))-theta(i-1)*cos(theta(i)-theta(i-1))+theta(i)))*v(i);
    end
    
    % 计算位置
    pos(1,1)= k*theta_h*cos(theta_h);
    pos(1,2)= k*theta_h*sin(theta_h);
    for i = 2:224
        pos(i,1)= k*theta(i-1)*cos(theta(i-1));
        pos(i,2)= k*theta(i-1)*sin(theta(i-1));
    end
    
    % 存储结果
    for i = 1:224
        ans1(i*2-1,t+1) = pos(i,1);
        ans1(i*2,t+1) = pos(i,2);
        ans2(i,t+1) = v(i);
    end
end

% 绘图
figure;
l1 = plot(pos(:, 1), pos(:, 2), '-o', 'LineWidth', 3, 'MarkerSize', 10);
hold on;
theta2 = linspace(0, theta_s, 10000);
r_plt = k * theta2;
x = r_plt .* cos(theta2);
y = r_plt .* sin(theta2);
l2 = plot(x, y, 'r', 'LineWidth', 1.5);
l3 = plot(pos(1,1), pos(1,2), 'o', 'Color', 'g', 'MarkerSize', 15, 'LineWidth', 2);
l4 = plot(pos(224,1), pos(224,2), 'x', 'Color', 'y', 'MarkerSize', 15, 'LineWidth', 2);
axis equal;
xlabel('X');
ylabel('Y');
legend([l1, l2, l3, l4], {'板凳龙', '螺线', '龙头', '龙尾'});
title('螺线及板凳龙位置');
grid on;