clc
clear

% 初始化参数
k = 1.7/(2*pi);  % 螺线参数
v_h = 1;  % 龙头速度 (m/s)
theta_s = 9/1.7*pi;  % 初始角度
len_h = 2.86;  % 龙头长度 (m)
len_b = 1.65;  % 龙身长度 (m)

% 定义旋转矩阵
rot = [cos(0.5/1.7*pi), -sin(0.5/1.7*pi);
       sin(0.5/1.7*pi), cos(0.5/1.7*pi)];

% 时间参数设置
t_ini = -100;  % 初始时间
t_iter = 1;  % 时间步长
t_num = 201;  % 时间点数量
dt = 0.00002;  % 微小时间步长，用于计算速度

% 初始化位置、角度和速度数组
pos_h = zeros(2, t_num);  % 龙头位置
pos = zeros(2, t_num, 224);  % 所有节点位置
pos_before = zeros(2, t_num, 224);  % 计算速度用的前一时刻位置
pos_after = zeros(2, t_num, 224);  % 计算速度用的后一时刻位置
pos_state = zeros(t_num, 224);  % 位置状态
theta = zeros(t_num, 224);  % 角度
rou = zeros(t_num, 224);  % 到原点的距离
v = zeros(t_num, 224);  % 速度

% 主循环，计算每个时间点的位置
for j = 1:t_num
    t=t_ini+(j-1)*t_iter;
    if t<=0
        tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
        func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*t;
        theta_h = fsolve(func_sh, 0);
        pos_h(:,j) = [k*theta_h*cos(theta_h);
                 k*theta_h*sin(theta_h)];
    elseif t>0&&t<=3*pi/v_h
        pos_h(:,j) = rot*[-1.5-3*cos(v_h*t/3);3*sin(v_h*t/3)];
    elseif t>3*pi/v_h&&t<=4.5*pi/v_h
        pos_h(:,j) = rot*[3-1.5*cos(v_h*(t-3*pi/v_h)/1.5);
                 -1.5*sin(v_h*(t-3*pi/v_h)/1.5)];
    else
        tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
        func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*(4.5*pi/v_h-t);
        theta_h = fsolve(func_sh, 0);
        pos_h(:,j) = [-k*theta_h*cos(theta_h);
                 -k*theta_h*sin(theta_h)];
    end

    pos(1,j,1)=pos_h(1,j);
    pos(2,j,1)=pos_h(2,j);
    rou(j,1) = sqrt((pos_h(1,j))^2+(pos_h(2,j))^2);
    if rou(j,1)>4.5
        func_th = @(dtheta) k^2*(theta_h+dtheta)^2 - 2*k^2*theta_h*(theta_h+dtheta)*cos(dtheta) + k^2*theta_h^2 - len_h^2;
        dtheta = fsolve(func_th,-0.15*sign(t-7.50000101));
        theta(j,2) = theta_h + dtheta;
        if theta(j,2)>=9/1.7*pi
            pos(1,j,2)=-k*theta(j,2)*cos(theta(j,2))*sign(t-7.50000101);
            pos(2,j,2)=-k*theta(j,2)*sin(theta(j,2))*sign(t-7.50000101);
            pos_state(j,2)=sign(t-7.50000101);
        else
            temp_pos=rot\[pos(1,j,1);pos(2,j,1)];
            temp_x0=temp_pos(1);
            temp_y0=temp_pos(2);
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_h^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_h^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos(1,j,2) = final_pos(1);
            pos(2,j,2) = final_pos(2);
        end
    else
        temp_pos=rot\[pos(1,j,1);pos(2,j,1)];
        temp_x0=temp_pos(1);
        temp_y0=temp_pos(2);
        if temp_x0>1.5+(len_h)^2/3&&temp_x0<=4.5
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_h^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_h^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos(1,j,2) = final_pos(1);
            pos(2,j,2) = final_pos(2);
        elseif temp_x0>-4.5+(len_h)^2/6 && temp_x0<=1.5+(len_h)^2/3
            syms sym_x;
            eqn = ((2*temp_x0+3)^2+4*temp_y0^2)*sym_x^2 + (12*temp_y0^2-(4*temp_x0+6)*(6.75+temp_x0^2+temp_y0^2-len_h^2))*sym_x + (6.75+temp_x0^2+temp_y0^2-len_h^2)^2-27*temp_y0^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            end            
            final_pos = rot*[temp_x;temp_y];
            pos(1,j,2) = final_pos(1);
            pos(2,j,2) = final_pos(2);
        else
            func_cl = @(temp_theta) k^2*temp_theta^2-2*k*temp_theta*(pos(1,j,1)*cos(temp_theta)+pos(2,j,1)*sin(temp_theta))+(pos(1,j,1))^2+(pos(2,j,1))^2-len_h^2;
            temp_theta = fsolve(func_cl,5.5*pi);
            pos(1,j,2) = k*temp_theta*cos(temp_theta);
            pos(2,j,2) = k*temp_theta*sin(temp_theta);
            theta(j,2) = temp_theta;
            pos_state(j,2) = -1;
        end 
    end
 rou(j,2) = sqrt((pos(1,j,2))^2+(pos(2,j,2))^2);
 for l=2:224
    if rou(j,l)>4.5
        func_th = @(dtheta) k^2*(theta(j,l)+dtheta)^2 - 2*k^2*theta(j,l)*(theta(j,l)+dtheta)*cos(dtheta) + k^2*theta(j,l)^2 - len_b^2;
        dtheta = fsolve(func_th,-0.15*pos_state(j,l));
        theta(j,l+1) = theta(j,l) + dtheta;
        if theta(j,l+1)>=9/1.7*pi
            pos(1,j,l+1)=-k*theta(j,l+1)*cos(theta(j,l+1))*pos_state(j,l);
            pos(2,j,l+1)=-k*theta(j,l+1)*sin(theta(j,l+1))*pos_state(j,l);
            pos_state(j,l+1)=pos_state(j,l);
        else
            temp_pos=rot\[pos(1,j,l);pos(2,j,l)];
            temp_x0=temp_pos(1);
            temp_y0=temp_pos(2);
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_b^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_b^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos(1,j,l+1) = final_pos(1);
            pos(2,j,l+1) = final_pos(2);
        end
    else
        temp_pos=rot\[pos(1,j,l);pos(2,j,l)];
        temp_x0=temp_pos(1);
        temp_y0=temp_pos(2);
        if temp_x0>1.5+(len_b)^2/3&&temp_x0<=4.5
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_b^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_b^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos(1,j,l+1) = final_pos(1);
            pos(2,j,l+1) = final_pos(2);
        elseif temp_x0>-4.5+(len_b)^2/6 && temp_x0<=1.5+(len_b)^2/3
            syms sym_x;
            eqn = ((2*temp_x0+3)^2+4*temp_y0^2)*sym_x^2 + (12*temp_y0^2-(4*temp_x0+6)*(6.75+temp_x0^2+temp_y0^2-len_b^2))*sym_x + (6.75+temp_x0^2+temp_y0^2-len_b^2)^2-27*temp_y0^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos(1,j,l+1) = final_pos(1);
            pos(2,j,l+1) = final_pos(2);
        else
            func_cl = @(temp_theta) k^2*temp_theta^2-2*k*temp_theta*(pos(1,j,l)*cos(temp_theta)+pos(2,j,l)*sin(temp_theta))+(pos(1,j,l))^2+(pos(2,j,l))^2-len_b^2;
            temp_theta = fsolve(func_cl,5.5*pi);
            pos(1,j,l+1) = k*temp_theta*cos(temp_theta);
            pos(2,j,l+1) = k*temp_theta*sin(temp_theta);
            pos_state(j,l+1) = -1;
            theta(j,l+1) = temp_theta;
        end
    end
 rou(j,l+1) = sqrt((pos(1,j,l+1))^2+(pos(2,j,l+1))^2);
 end
end


for j = 1:t_num
    t=t_ini+(j-1)*t_iter-0.5*dt;
    if t<=0
        tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
        func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*t;
        theta_h = fsolve(func_sh, 0);
        pos_h(:,j) = [k*theta_h*cos(theta_h);
                 k*theta_h*sin(theta_h)];
    elseif t>0&&t<=3*pi/v_h
        pos_h(:,j) = rot*[-1.5-3*cos(v_h*t/3);3*sin(v_h*t/3)];
    elseif t>3*pi/v_h&&t<=4.5*pi/v_h
        pos_h(:,j) = rot*[3-1.5*cos(v_h*(t-3*pi/v_h)/1.5);
                 -1.5*sin(v_h*(t-3*pi/v_h)/1.5)];
    else
        tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
        func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*(4.5*pi/v_h-t);
        theta_h = fsolve(func_sh, 0);
        pos_h(:,j) = [-k*theta_h*cos(theta_h);
                 -k*theta_h*sin(theta_h)];
    end

    pos_before(1,j,1)=pos_h(1,j);
    pos_before(2,j,1)=pos_h(2,j);
    rou(j,1) = sqrt((pos_h(1,j))^2+(pos_h(2,j))^2);
    if rou(j,1)>4.5
        func_th = @(dtheta) k^2*(theta_h+dtheta)^2 - 2*k^2*theta_h*(theta_h+dtheta)*cos(dtheta) + k^2*theta_h^2 - len_h^2;
        dtheta = fsolve(func_th,-0.15*sign(t));
        theta(j,2) = theta_h + dtheta;
        if theta(j,2)>=9/1.7*pi
            pos_before(1,j,2)=-k*theta(j,2)*cos(theta(j,2))*sign(t-7.50000101);
            pos_before(2,j,2)=-k*theta(j,2)*sin(theta(j,2))*sign(t-7.50000101);
            pos_state(j,2)=sign(t-7.50000101);
        else
            temp_pos=rot\[pos_before(1,j,1);pos_before(2,j,1)];
            temp_x0=temp_pos(1);
            temp_y0=temp_pos(2);
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_h^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_h^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_before(1,j,2) = final_pos(1);
            pos_before(2,j,2) = final_pos(2);
        end
    else
        temp_pos=rot\[pos_before(1,j,1);pos_before(2,j,1)];
        temp_x0=temp_pos(1);
        temp_y0=temp_pos(2);
        if temp_x0>1.5+(len_h)^2/3&&temp_x0<=4.5
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_h^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_h^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_before(1,j,2) = final_pos(1);
            pos_before(2,j,2) = final_pos(2);
        elseif temp_x0>-4.5+(len_h)^2/6 && temp_x0<=1.5+(len_h)^2/3
            syms sym_x;
            eqn = ((2*temp_x0+3)^2+4*temp_y0^2)*sym_x^2 + (12*temp_y0^2-(4*temp_x0+6)*(6.75+temp_x0^2+temp_y0^2-len_h^2))*sym_x + (6.75+temp_x0^2+temp_y0^2-len_h^2)^2-27*temp_y0^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_before(1,j,2) = final_pos(1);
            pos_before(2,j,2) = final_pos(2);
        else
            func_cl = @(temp_theta) k^2*temp_theta^2-2*k*temp_theta*(pos_before(1,j,1)*cos(temp_theta)+pos_before(2,j,1)*sin(temp_theta))+(pos_before(1,j,1))^2+(pos_before(2,j,1))^2-len_h^2;
            temp_theta = fsolve(func_cl,5.5*pi);
            pos_before(1,j,2) = k*temp_theta*cos(temp_theta);
            pos_before(2,j,2) = k*temp_theta*sin(temp_theta);
            theta(j,2) = temp_theta;
            pos_state(j,2) = -1;
        end 
    end
 rou(j,2) = sqrt((pos_before(1,j,2))^2+(pos_before(2,j,2))^2);
 for l=2:224
    if rou(j,l)>4.5
        func_th = @(dtheta) k^2*(theta(j,l)+dtheta)^2 - 2*k^2*theta(j,l)*(theta(j,l)+dtheta)*cos(dtheta) + k^2*theta(j,l)^2 - len_b^2;
        dtheta = fsolve(func_th,-0.15*pos_state(j,l));
        theta(j,l+1) = theta(j,l) + dtheta;
        if theta(j,l+1)>=9/1.7*pi
            pos_before(1,j,l+1)=-k*theta(j,l+1)*cos(theta(j,l+1))*pos_state(j,l);
            pos_before(2,j,l+1)=-k*theta(j,l+1)*sin(theta(j,l+1))*pos_state(j,l);
            pos_state(j,l+1)=pos_state(j,l);
        else
            temp_pos=rot\[pos_before(1,j,l);pos_before(2,j,l)];
            temp_x0=temp_pos(1);
            temp_y0=temp_pos(2);
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_b^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_b^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_before(1,j,l+1) = final_pos(1);
            pos_before(2,j,l+1) = final_pos(2);
        end
    else
        temp_pos=rot\[pos_before(1,j,l);pos_before(2,j,l)];
        temp_x0=temp_pos(1);
        temp_y0=temp_pos(2);
        if temp_x0>1.5+(len_b)^2/3&&temp_x0<=4.5
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_b^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_b^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_before(1,j,l+1) = final_pos(1);
            pos_before(2,j,l+1) = final_pos(2);
        elseif temp_x0>-4.5+(len_b)^2/6 && temp_x0<=1.5+(len_b)^2/3
            syms sym_x;
            eqn = ((2*temp_x0+3)^2+4*temp_y0^2)*sym_x^2 + (12*temp_y0^2-(4*temp_x0+6)*(6.75+temp_x0^2+temp_y0^2-len_b^2))*sym_x + (6.75+temp_x0^2+temp_y0^2-len_b^2)^2-27*temp_y0^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_before(1,j,l+1) = final_pos(1);
            pos_before(2,j,l+1) = final_pos(2);
        else
            func_cl = @(temp_theta) k^2*temp_theta^2-2*k*temp_theta*(pos_before(1,j,l)*cos(temp_theta)+pos_before(2,j,l)*sin(temp_theta))+(pos_before(1,j,l))^2+(pos_before(2,j,l))^2-len_b^2;
            temp_theta = fsolve(func_cl,5.5*pi);
            pos_before(1,j,l+1) = k*temp_theta*cos(temp_theta);
            pos_before(2,j,l+1) = k*temp_theta*sin(temp_theta);
            pos_state(j,l+1) = -1;
            theta(j,l+1) = temp_theta;
        end
    end
 rou(j,l+1) = sqrt((pos_before(1,j,l+1))^2+(pos_before(2,j,l+1))^2);
 end
end



for j = 1:t_num
    t=t_ini+(j-1)*t_iter+0.5*dt;
    if t<=0
        tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
        func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*t;
        theta_h = fsolve(func_sh, 0);
        pos_h(:,j) = [k*theta_h*cos(theta_h);
                 k*theta_h*sin(theta_h)];
    elseif t>0&&t<=3*pi/v_h
        pos_h(:,j) = rot*[-1.5-3*cos(v_h*t/3);3*sin(v_h*t/3)];
    elseif t>3*pi/v_h&&t<=4.5*pi/v_h
        pos_h(:,j) = rot*[3-1.5*cos(v_h*(t-3*pi/v_h)/1.5);
                 -1.5*sin(v_h*(t-3*pi/v_h)/1.5)];
    else
        tot_s = k/2*(theta_s*(1+theta_s^2)^0.5+log(theta_s+(1+theta_s^2)^0.5));
        func_sh = @(theta) k/2*(theta*(1+theta^2)^0.5+log(theta+(1+theta^2)^0.5)) - tot_s + v_h*(4.5*pi/v_h-t);
        theta_h = fsolve(func_sh, 0);
        pos_h(:,j) = [-k*theta_h*cos(theta_h);
                 -k*theta_h*sin(theta_h)];
    end

    pos_after(1,j,1)=pos_h(1,j);
    pos_after(2,j,1)=pos_h(2,j);
    rou(j,1) = sqrt((pos_h(1,j))^2+(pos_h(2,j))^2);
    if rou(j,1)>4.5
        func_th = @(dtheta) k^2*(theta_h+dtheta)^2 - 2*k^2*theta_h*(theta_h+dtheta)*cos(dtheta) + k^2*theta_h^2 - len_h^2;
        dtheta = fsolve(func_th,-0.15*sign(t-7.50000101));
        theta(j,2) = theta_h + dtheta;
        if theta(j,2)>=9/1.7*pi
            pos_after(1,j,2)=-k*theta(j,2)*cos(theta(j,2))*sign(t-7.50000101);
            pos_after(2,j,2)=-k*theta(j,2)*sin(theta(j,2))*sign(t-7.50000101);
            pos_state(j,2)=sign(t-7.50000101);
        else
            temp_pos=rot\[pos_after(1,j,1);pos_after(2,j,1)];
            temp_x0=temp_pos(1);
            temp_y0=temp_pos(2);
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_h^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_h^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_after(1,j,2) = final_pos(1);
            pos_after(2,j,2) = final_pos(2);
        end
    else
        temp_pos=rot\[pos_after(1,j,1);pos_after(2,j,1)];
        temp_x0=temp_pos(1);
        temp_y0=temp_pos(2);
        if temp_x0>1.5+(len_h)^2/3&&temp_x0<=4.5
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_h^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_h^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_after(1,j,2) = final_pos(1);
            pos_after(2,j,2) = final_pos(2);
        elseif temp_x0>-4.5+(len_h)^2/6 && temp_x0<=1.5+(len_h)^2/3
            syms sym_x;
            eqn = ((2*temp_x0+3)^2+4*temp_y0^2)*sym_x^2 + (12*temp_y0^2-(4*temp_x0+6)*(6.75+temp_x0^2+temp_y0^2-len_h^2))*sym_x + (6.75+temp_x0^2+temp_y0^2-len_h^2)^2-27*temp_y0^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_h) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_after(1,j,2) = final_pos(1);
            pos_after(2,j,2) = final_pos(2);
        else
            func_cl = @(temp_theta) k^2*temp_theta^2-2*k*temp_theta*(pos_after(1,j,1)*cos(temp_theta)+pos_after(2,j,1)*sin(temp_theta))+(pos_after(1,j,1))^2+(pos_after(2,j,1))^2-len_h^2;
            temp_theta = fsolve(func_cl,5.5*pi);
            pos_after(1,j,2) = k*temp_theta*cos(temp_theta);
            pos_after(2,j,2) = k*temp_theta*sin(temp_theta);
            theta(j,2) = temp_theta;
            pos_state(j,2) = -1;
        end 
    end
 rou(j,2) = sqrt((pos_after(1,j,2))^2+(pos_after(2,j,2))^2);
 for l=2:224
    if rou(j,l)>4.5
        func_th = @(dtheta) k^2*(theta(j,l)+dtheta)^2 - 2*k^2*theta(j,l)*(theta(j,l)+dtheta)*cos(dtheta) + k^2*theta(j,l)^2 - len_b^2;
        dtheta = fsolve(func_th,-0.15*pos_state(j,l));
        theta(j,l+1) = theta(j,l) + dtheta;
        if theta(j,l+1)>=9/1.7*pi
            pos_after(1,j,l+1)=-k*theta(j,l+1)*cos(theta(j,l+1))*pos_state(j,l);
            pos_after(2,j,l+1)=-k*theta(j,l+1)*sin(theta(j,l+1))*pos_state(j,l);
            pos_state(j,l+1)=pos_state(j,l);
        else
            temp_pos=rot\[pos_after(1,j,l);pos_after(2,j,l)];
            temp_x0=temp_pos(1);
            temp_y0=temp_pos(2);
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_b^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_b^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_after(1,j,l+1) = final_pos(1);
            pos_after(2,j,l+1) = final_pos(2);
        end
    else
        temp_pos=rot\[pos_after(1,j,l);pos_after(2,j,l)];
        temp_x0=temp_pos(1);
        temp_y0=temp_pos(2);
        if temp_x0>1.5+(len_b)^2/3&&temp_x0<=4.5
            syms sym_x;
            eqn = ((2*temp_x0-6)^2+4*temp_y0^2)*sym_x^2 + (-24*temp_y0^2+(4*temp_x0-12)*(len_b^2-temp_x0^2-temp_y0^2+6.75))*sym_x + 27*temp_y0^2+(len_b^2-temp_x0^2-temp_y0^2+6.75)^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = -sqrt(6*temp_x-(temp_x)^2-6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_after(1,j,l+1) = final_pos(1);
            pos_after(2,j,l+1) = final_pos(2);
        elseif temp_x0>-4.5+(len_b)^2/6 && temp_x0<=1.5+(len_b)^2/3
            syms sym_x;
            eqn = ((2*temp_x0+3)^2+4*temp_y0^2)*sym_x^2 + (12*temp_y0^2-(4*temp_x0+6)*(6.75+temp_x0^2+temp_y0^2-len_b^2))*sym_x + (6.75+temp_x0^2+temp_y0^2-len_b^2)^2-27*temp_y0^2 == 0;
            sym_x = solve(eqn,sym_x);
            temp_xs = double(sym_x);
            temp_x = min(real(temp_xs));
            temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            if abs(sqrt((temp_x-temp_x0)^2+(temp_y-temp_y0)^2) - len_b) > 0.01
                temp_x = max(real(temp_xs));
                temp_y = sqrt(-(temp_x)^2-3*temp_x+6.75);
            end
            final_pos = rot*[temp_x;temp_y];
            pos_after(1,j,l+1) = final_pos(1);
            pos_after(2,j,l+1) = final_pos(2);
        else
            func_cl = @(temp_theta) k^2*temp_theta^2-2*k*temp_theta*(pos_after(1,j,l)*cos(temp_theta)+pos_after(2,j,l)*sin(temp_theta))+(pos_after(1,j,l))^2+(pos_after(2,j,l))^2-len_b^2;
            temp_theta = fsolve(func_cl,5.5*pi);
            pos_after(1,j,l+1) = k*temp_theta*cos(temp_theta);
            pos_after(2,j,l+1) = k*temp_theta*sin(temp_theta);
            pos_state(j,l+1) = -1;
            theta(j,l+1) = temp_theta;
        end
    end
 rou(j,l+1) = sqrt((pos_after(1,j,l+1))^2+(pos_after(2,j,l+1))^2);
 end
end


for j=1:224
    v(:,j)=sqrt((pos_before(1,:,j)-pos_after(1,:,j)).^2+(pos_before(2,:,j)-pos_after(2,:,j)).^2)/dt;
end

out_pos = zeros(201,448);
out_v = zeros(201,224);
for m=1:224
    out_pos(:,2*m-1) = pos(1,:,m);
    out_pos(:,2*m) = pos(2,:,m);
end

%xlswrite('result4.xlsx',round(out_pos.',6),'位置','B2:GT449');
%xlswrite('result4.xlsx',round(v.',6),'速度','B2:GT225');

% 计算最大允许速度和实际最大速度
v_max_h = 2/max(v(:));
max_v = max(v(:))
